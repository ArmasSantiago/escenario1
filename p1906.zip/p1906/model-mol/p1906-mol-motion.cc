/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 *  Copyright © 2014 by IEEE.
 *
 *  This source file is an essential part of IEEE Std 1906.1,
 *  Recommended Practice for Nanoscale and Molecular
 *  Communication Framework.
 *  Verbatim copies of this source file may be used and
 *  distributed without restriction. Modifications to this source
 *  file as permitted in IEEE Std 1906.1 may also be made and
 *  distributed. All other uses require permission from the IEEE
 *  Standards Department (stds-ipr@ieee.org). All other rights
 *  reserved.
 *
 *  This source file is provided on an AS IS basis.
 *  The IEEE disclaims ANY WARRANTY EXPRESS OR IMPLIED INCLUDING
 *  ANY WARRANTY OF MERCHANTABILITY AND FITNESS FOR USE FOR A
 *  PARTICULAR PURPOSE.
 *  The user of the source file shall indemnify and hold
 *  IEEE harmless from any damages or liability arising out of
 *  the use thereof.
 *
 * Author: Giuseppe Piro - Telematics Lab Research Group
 *                         Politecnico di Bari
 *                         giuseppe.piro@poliba.it
 *                         telematics.poliba.it/piro
 **************************************************************
 * Santiago Armas
 * sdarmas.fie@unach.edu.ec
 * 2023
 **************************************************************
 */

#include "ns3/log.h"

#include "p1906-mol-motion.h"
#include "ns3/p1906-communication-interface.h"
#include "ns3/p1906-message-carrier.h"
#include "ns3/p1906-field.h"
#include "ns3/mobility-model.h"
#include "ns3/p1906-net-device.h"
#include <ns3/spectrum-value.h>
#include "p1906-mol-message-carrier.h"
#include <stddef.h>
#include <stdio.h>
#include <stdint.h>
#include <cmath>


namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("P1906MOLMotion");

TypeId P1906MOLMotion::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::P1906MOLMotion")
    .SetParent<P1906Motion> ();
  return tid;
}

P1906MOLMotion::P1906MOLMotion ()
{
  NS_LOG_FUNCTION (this << "===Sección-Creación del componente Movimiento/Motion===");
}

P1906MOLMotion::~P1906MOLMotion ()
{
  NS_LOG_FUNCTION (this);
}


double
P1906MOLMotion::ComputePropagationDelay (Ptr<P1906CommunicationInterface> src,
		                                Ptr<P1906CommunicationInterface> dst,
		                                Ptr<P1906MessageCarrier> message,
		                                Ptr<P1906Field> field)
{

  /*
   * The Motion component implements a propagation model as presented in
   *
   * Detection Techniques for Diffusion-based Molecular Communication
   * I Llatser, A Cabellos-Aparicio, M Pierobon, E Alarcón
   * Selected Areas in Communications, IEEE Journal on 31 (12), 726-734
   *
   */

  NS_LOG_FUNCTION (this << "Fick's bajo");

  Ptr<MobilityModel> srcMobility = src->GetP1906NetDevice ()->GetNode ()->GetObject<MobilityModel> ();
  Ptr<MobilityModel> dstMobility = dst->GetP1906NetDevice ()->GetNode ()->GetObject<MobilityModel> ();


  double distance = dstMobility->GetDistanceFrom (srcMobility);
  double delay = pow(distance,2)/(GetDiffusionConefficient ()*6);
  double diffusion = GetDiffusionConefficient ();

  NS_LOG_FUNCTION (this << "[distancia,difusión,retardo]" << distance <<  diffusion << delay);
 
  return delay;
}


Ptr<P1906MessageCarrier>
P1906MOLMotion::CalculateReceivedMessageCarrier(Ptr<P1906CommunicationInterface> src,
		                                       Ptr<P1906CommunicationInterface> dst,
		                                       Ptr<P1906MessageCarrier> message,
		                                       Ptr<P1906Field> field)
{

  NS_LOG_FUNCTION (this);
    Ptr<MobilityModel> srcMobility = src->GetP1906NetDevice ()->GetNode ()->GetObject<MobilityModel> ();
    Ptr<MobilityModel> dstMobility = dst->GetP1906NetDevice ()->GetNode ()->GetObject<MobilityModel> ();
    double distance = dstMobility->GetDistanceFrom(srcMobility);
    double pulseinter=2; int t=16;    
    double delay = pow(distance,2)/(GetDiffusionConefficient ()*6);
    double tiempo_total = m_duration.GetSeconds()+t;
    double tiempo_simbolo = delay+(pulseinter/2);
    double duracion_bit = tiempo_total / (8 * tiempo_simbolo);
    std::vector<double> tiempo_inicio(8, 0.0);
    std::vector<double> tiempo_fin(8, 0.0);
    for (int i = 1; i < 8; i++) {
        tiempo_inicio[i] = tiempo_inicio[i - 1] + duracion_bit;
    }
    for (int i = 0; i < 8; i++) {
        tiempo_fin[i] = tiempo_inicio[i] + duracion_bit;
    }
    std::string tiempoinicio = "";
    for (int i = 0; i < 8; i++) {
        tiempoinicio += std::to_string(tiempo_inicio[i])+"||";
    }
    NS_LOG_FUNCTION("[Tiempos de inicio de cada bit:]" << tiempoinicio);
    std::string tiempofinal = "";
    for (int i = 0; i < 8; i++) {
        tiempofinal += std::to_string(tiempo_fin[i])+"||";
    }
    NS_LOG_FUNCTION("[Tiempos de finalización de cada bit:]" << tiempofinal);
    double isi = 0.0;
    for (std::vector<double>::size_type i = 0; i < tiempo_inicio.size() - 1; i++) {
        double tiempo_inicio_actual = tiempo_inicio[i];
        double tiempo_inicio_siguiente = tiempo_fin[i];
        isi += tiempo_inicio_siguiente-1 - tiempo_inicio_actual;
    }
        isi /= tiempo_inicio.size();
        NS_LOG_FUNCTION("[Interferencia Inter-Simbolos:]" << isi);
     return message;
     
}

void
P1906MOLMotion::SetDiffusionCoefficient (double d)
{
  NS_LOG_FUNCTION (this << d);
  m_diffusionCoefficient = d;
}

double
P1906MOLMotion::GetDiffusionConefficient (void)
{
  NS_LOG_FUNCTION (this);
  return m_diffusionCoefficient;
}

void
P1906MOLMotion::SetDuration (Time t)
{
  NS_LOG_FUNCTION (this << t);
  m_duration = t;
}

Time
P1906MOLMotion::GetDuration (void)
{
  NS_LOG_FUNCTION (this);
  return m_duration;
}



} // namespace ns3
